package com.neurofleetx;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NeurofleetxBackendApplication {
    public static void main(String[] args) {
        SpringApplication.run(NeurofleetxBackendApplication.class, args);
    }
}
